-- phpMyAdmin SQL Dump
-- version 3.4.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 19, 2013 at 07:27 AM
-- Server version: 5.5.13
-- PHP Version: 5.4.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `recipes`
--
CREATE DATABASE `recipes` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `recipes`;

-- --------------------------------------------------------

--
-- Table structure for table `directions`
--

CREATE TABLE IF NOT EXISTS `directions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) NOT NULL,
  `text` text NOT NULL,
  `weight` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=661 ;

--
-- Dumping data for table `directions`
--

INSERT INTO `directions` (`id`, `rid`, `text`, `weight`) VALUES
(656, 1, 'Remove from heat immediately and stir in peanut butter until it is mixed evenly.', 0),
(657, 1, 'Mix in Rice Krispies.', 0),
(658, 1, 'In a 9x16 pan, pour out Rice Krispies mixture and spread evently in the pan', 0),
(659, 1, 'Melt chocolate chips and spread over Rice Krispies mixture. Allow to completely cool before serving!', 0),
(660, 1, 'Over low heat, combine corn syrup and sugar in a large pan. Stir continuously until tiny bubbles begin to form.', 0);

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `filename` varchar(255) CHARACTER SET utf8 NOT NULL,
  `filemime` varchar(255) CHARACTER SET utf32 COLLATE utf32_bin NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`fid`, `rid`, `uid`, `filename`, `filemime`, `timestamp`) VALUES
(40, 1, 1, 'scotcharoos.jpg', 'image/jpeg', '2013-12-19 06:07:36');

-- --------------------------------------------------------

--
-- Table structure for table `ingredients`
--

CREATE TABLE IF NOT EXISTS `ingredients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `quantity` decimal(5,3) NOT NULL,
  `measurement` varchar(20) NOT NULL,
  `weight` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=708 ;

--
-- Dumping data for table `ingredients`
--

INSERT INTO `ingredients` (`id`, `rid`, `name`, `quantity`, `measurement`, `weight`) VALUES
(703, 1, 'Corn Syrup', '1.000', 'cup', 0),
(704, 1, 'Sugar', '1.000', 'cup', 1),
(705, 1, 'Peanut Butter', '1.000', 'cup', 2),
(706, 1, 'Rice Krispies', '6.000', 'cup', 3),
(707, 1, 'Chocolate Chips', '1.000', 'cup', 5);

-- --------------------------------------------------------

--
-- Table structure for table `paths`
--

CREATE TABLE IF NOT EXISTS `paths` (
  `rid` int(11) NOT NULL,
  `alias` varchar(255) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paths`
--

INSERT INTO `paths` (`rid`, `alias`) VALUES
(1, 'scotcharoos');

-- --------------------------------------------------------

--
-- Table structure for table `recipes`
--

CREATE TABLE IF NOT EXISTS `recipes` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `author` varchar(255) NOT NULL,
  `title` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `edited` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `recipes`
--

INSERT INTO `recipes` (`rid`, `author`, `title`, `created`, `edited`) VALUES
(1, 'nickjvm', 'Scotcharoos', '2013-12-13 04:19:11', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 NOT NULL,
  `hashed_password` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `username`, `email`, `hashed_password`, `created`) VALUES
(1, 'nickjvm', 'nickjvm@gmail.com', '', '2013-12-13 04:18:21');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
